import { DebitCardBean } from './debit-card-bean';

describe('DebitCardBean', () => {
  it('should create an instance', () => {
    expect(new DebitCardBean()).toBeTruthy();
  });
});
