import { DebitCardBean } from 'src/app/model/debit-card-bean';
export class Transaction {
public transactionId:number;
public UCI:number;
public accountNumber:number;
public transactionDescription:String;
public transactionDate:Date;
public transactionAmount:number;
public debitBeanObject:DebitCardBean;
public transactionType:Transaction;
public transactionMode:Transaction;
}

enum TransactionType {
	CREDIT, DEBIT,
}
enum TransactionMode {
	ONLINE, CASH,
}
