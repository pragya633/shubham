import { CreditCardBean } from './credit-card-bean';

describe('CreditCardBean', () => {
  it('should create an instance', () => {
    expect(new CreditCardBean()).toBeTruthy();
  });
});
