import { CustomerBean } from 'src/app/model/customer-bean';
export class AccountBean {
    public accountNumber:number;
    public customerBeanObject:CustomerBean;

}


