export class CustomerBean {
    public UCI:number;
    public firstName:string;
    public lastName:string;
}
