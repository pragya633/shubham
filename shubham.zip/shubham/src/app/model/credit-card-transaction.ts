import { CreditCardBean } from 'src/app/model/credit-card-bean';
export class CreditCardTransaction {
    public transactionId:number;
public UCI:number;
public dateOfTran:Date;
public amount:number;
public description:String;
public creditBeanObject:CreditCardBean;
}

enum TransactionType {
	CREDIT, DEBIT,
}
enum TransactionMode {
	ONLINE, CASH,
}