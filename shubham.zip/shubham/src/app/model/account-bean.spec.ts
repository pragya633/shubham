import { AccountBean } from './account-bean';

describe('AccountBean', () => {
  it('should create an instance', () => {
    expect(new AccountBean()).toBeTruthy();
  });
});
