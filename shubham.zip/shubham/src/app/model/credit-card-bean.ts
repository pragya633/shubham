import { CustomerBean} from 'src/app/model/customer-bean';


export class CreditCardBean {
        public cardNumber:number;
        public creditScorenumber;
        public creditLimit:number;
        public income:number;
        public cardStatus:String;
        public nameOnCard:String;
        public cvvNum:String;
        public currentPin:String;
        public cardType:String;
        public dateOfExpiry:Date;
        public adminRemarks:String;
        public customerBeanObject: CustomerBean;
}

enum CardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}