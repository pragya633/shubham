export class CaseIdBean {
public caseIdTotal:string;
public applicationId:number;
public caseTimeStamp:Date;
public requestMap:string;
public statusOfServiceRequest:string;
public accountNumber:number;
public bankTimeStamp:Date;
public userId:string;
}
