import { CustomerBean } from './customer-bean';

describe('CustomerBean', () => {
  it('should create an instance', () => {
    expect(new CustomerBean()).toBeTruthy();
  });
});
