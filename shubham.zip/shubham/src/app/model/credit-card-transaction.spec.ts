import { CreditCardTransaction } from './credit-card-transaction';

describe('CreditCardTransaction', () => {
  it('should create an instance', () => {
    expect(new CreditCardTransaction()).toBeTruthy();
  });
});
