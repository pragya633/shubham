import { CaseIdBean } from './case-id-bean';

describe('CaseIdBean', () => {
  it('should create an instance', () => {
    expect(new CaseIdBean()).toBeTruthy();
  });
});
