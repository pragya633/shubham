import { AccountBean } from 'src/app/model/account-bean';
export class DebitCardBean {
    public cardNumber:number;
public Status:String;
public nameOnCard:String;
public cvvNum:String;
public currentPin:String;
public Type:String;
public dateOfExpiry:Date;
public accountBeanObject:AccountBean;
}

enum CardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}